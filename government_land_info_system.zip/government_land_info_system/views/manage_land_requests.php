<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';

if (isset($_POST['approve'])) {
    $request_id = $_POST['request_id'];
    $sql = "UPDATE land_requests SET status='Approved' WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
}

if (isset($_POST['reject'])) {
    $request_id = $_POST['request_id'];
    $sql = "UPDATE land_requests SET status='Rejected' WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
}

$sql = "SELECT id, applicant_name, land_id, status FROM land_requests";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Land Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        button {
            padding: 5px 10px;
            margin: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manage Land Requests</h2>
        <table>
            <tr><th>ID</th><th>Applicant Name</th><th>Land ID</th><th>Status</th><th>Action</th></tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['applicant_name'] ?></td>
                    <td><?= $row['land_id'] ?></td>
                    <td><?= $row['status'] ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                            <button type="submit" name="approve">Approve</button>
                            <button type="submit" name="reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <br>
        <a href="superadmin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
