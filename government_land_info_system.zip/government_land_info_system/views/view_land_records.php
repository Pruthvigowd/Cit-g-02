<?php
session_start();

// Redirect if user is not logged in
if (!isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$role = $_SESSION['role']; // Get logged-in user's role

include_once '../config/db.php';

// Fetch land records
$sql = "SELECT * FROM land_records ORDER BY created_at DESC";
$result = $conn->query($sql);

// Determine dashboard redirect based on user role
$dashboard_page = ($role === 'superadmin') ? "dashboard_superadmin.php" : (($role === 'admin') ? "dashboard_admin.php" : "dashboard_public.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Land Records</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        .container { margin: 20px auto; width: 80%; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #007BFF; color: white; }
        img { width: 100px; height: auto; }
        #map { height: 400px; width: 100%; margin-top: 20px; }
    </style>
    <script>
        function initMap() {
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 5,
                center: { lat: 20.5937, lng: 78.9629 } // Default center (India)
            });

            <?php while ($row = $result->fetch_assoc()) { ?>
                var marker = new google.maps.Marker({
                    position: { lat: <?php echo $row['latitude']; ?>, lng: <?php echo $row['longitude']; ?> },
                    map: map,
                    title: "<?php echo $row['owner_name']; ?>"
                });
            <?php } ?>
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Land Records</h1>
        <table>
            <tr>
                <th>Owner Name</th>
                <th>Location</th>
                <th>Area (sq.m)</th>
                <th>Image</th>
            </tr>
            <?php 
            $result->data_seek(0); // Reset result pointer
            while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['owner_name']; ?></td>
                    <td><?php echo $row['location']; ?></td>
                    <td><?php echo $row['area']; ?></td>
                    <td><img src="../uploads/<?php echo $row['image']; ?>" alt="Land Image"></td>
                </tr>
            <?php } ?>
        </table>
        <div id="map"></div>
        <a href="<?php echo $dashboard_page; ?>">Back to Dashboard</a>
    </div>

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&callback=initMap"></script>
</body>
</html>
