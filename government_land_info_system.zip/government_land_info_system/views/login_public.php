<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public User Login</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            text-align: center;
            background: linear-gradient(to right, #1e1e1e, #4d4d4d);
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            margin-top: 50px;
        }
        form {
            background: #2e2e2e;
            padding: 20px;
            border-radius: 10px;
            display: inline-block;
            text-align: left;
            color: white;
            box-shadow: 0px 0px 15px rgba(255, 255, 255, 0.2);
        }
        input {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #777;
            border-radius: 5px;
            background: #1e1e1e;
            color: white;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #555555;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease-in-out;
        }
        button:hover {
            background: #222222;
        }
        .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Public User Login</h1>
        <form action="../controllers/login_public.php" method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>

        <?php
        // Show error messages if login fails
        if (isset($_GET['error'])) {
            echo "<p class='error-message'>" . htmlspecialchars($_GET['error']) . "</p>";
        }
        ?>
    </div>
</body>
</html>