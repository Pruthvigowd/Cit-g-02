<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    // WhatsApp API Link (Use your number here with country code)
    $whatsappNumber = "9739918088"; // Replace with your number
    $message = "New Registration:%0AName: $full_name%0APhone: $phone%0AEmail: $email%0AAddress: $address";

    $url = "https://wa.me/$whatsappNumber?text=$message";

    // Redirect to WhatsApp
    header("Location: $url");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
        .container { margin-top: 50px; width: 50%; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        input, textarea { width: 90%; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #ccc; }
        .btn { padding: 10px 20px; text-decoration: none; background: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; margin-bottom: 25px}
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registration Form</h2>
    <form method="POST" action="">
        <input type="text" name="full_name" placeholder="Full Name" required><br>
        <input type="tel" name="phone" placeholder="Phone Number" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <textarea name="address" placeholder="Address" required></textarea><br>
        <button type="submit" class="btn">Register</button>
    </form>
    <a href="dashboard_public.php" class="btn">Back to Dashboard</a>
</div>
</body>
</html>
