<?php
session_start();
include_once '../config/db.php';

// Determine the user's role
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'public';

// Set the correct dashboard redirect
$dashboard_redirect = "dashboard_public.php"; // Default for public users
if ($user_role === 'superadmin') {
    $dashboard_redirect = "dashboard_superadmin.php";
} elseif ($user_role === 'admin') {
    $dashboard_redirect = "dashboard_admin.php";
}

// Check if a property ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Invalid property ID.";
    exit();
}

$id = $_GET['id'];

// Fetch property details
$query = "SELECT * FROM land_records WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();

// If no property is found
if (!$property) {
    echo "Property not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.8s ease-in-out;
        }

        h2 {
            color: #333;
        }

        .details {
            text-align: left;
            margin-top: 20px;
        }

        .details p {
            margin: 10px 0;
            font-size: 16px;
        }

        .details img {
            width: 100%;
            max-width: 400px;
            border-radius: 5px;
            margin-top: 10px;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0056b3;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Property Details</h2>
    <div class="details">
        <p><strong>Owner Name:</strong> <?php echo $property['owner_name']; ?></p>
        <p><strong>Location:</strong> <?php echo $property['location']; ?></p>
        <p><strong>Area:</strong> <?php echo $property['area']; ?> sq.m</p>
        <p><strong>Latitude:</strong> <?php echo $property['latitude']; ?></p>
        <p><strong>Longitude:</strong> <?php echo $property['longitude']; ?></p>

        <p><strong>Location Link:</strong> 
            <?php if (!empty($property['latitude']) && !empty($property['longitude'])): ?>
                <a href="https://www.google.com/maps?q=<?php echo $property['latitude']; ?>,<?php echo $property['longitude']; ?>" target="_blank">View on Map</a>
            <?php else: ?>
                N/A
            <?php endif; ?>
        </p>

        <p><strong>Description:</strong> <?php echo nl2br($property['description']); ?></p>

        <p><strong>Image:</strong></p>
        <img src="../uploads/<?php echo $property['image']; ?>" alt="Property Image">
    </div>

    <a href="<?php echo $dashboard_redirect; ?>" class="btn">Back to Dashboard</a>
</div>

</body>
</html>
