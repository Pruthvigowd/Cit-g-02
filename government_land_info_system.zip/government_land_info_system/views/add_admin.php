<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';

// Enable error reporting for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = ""; // Variable to store success message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $admin_password = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
    $role = "admin"; // Since we are adding an admin

    // Check if email already exists
    $check_email = "SELECT id FROM users WHERE email = ?";
    $stmt_check = $conn->prepare($check_email);
    $stmt_check->bind_param("s", $admin_email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        $message = "Email already exists!";
    } else {
        // Insert new admin into the "users" table
        $sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("SQL Error: " . $conn->error);  // Show exact SQL error
        }

        $stmt->bind_param("ssss", $admin_name, $admin_email, $admin_password, $role);

        if ($stmt->execute()) {
            $message = "Admin added successfully!";
        } else {
            $message = "Error adding admin: " . $stmt->error;
        }

        $stmt->close();
    }
    $stmt_check->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            margin: 50px auto;
            width: 50%;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        input, button {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        a {
            display: inline-block;
            padding: 10px 15px;
            margin-top: 20px;
            text-decoration: none;
            color: white;
            background: #28a745;
            border-radius: 5px;
        }
        a:hover {
            background: #218838;
        }
    </style>
    <script>
        function showPopup(message) {
            if (message) {
                alert(message);
                window.location.href = "add_admin.php"; // Reload the page after clicking OK
            }
        }
    </script>
</head>
<body onload="showPopup('<?php echo $message; ?>')">
    <div class="container">
        <h1>Add Admin</h1>
        <form method="POST">
            <input type="text" name="admin_name" placeholder="Admin Name" required><br>
            <input type="email" name="admin_email" placeholder="Admin Email" required><br>
            <input type="password" name="admin_password" placeholder="Password" required><br>
            <button type="submit">Add Admin</button>
        </form>
        <a href="dashboard_superadmin.php">Back to Dashboard</a>
    </div>
</body>
</html>
