<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $owner_name = $_POST['owner_name'] ?? '';
    $location = $_POST['location'] ?? '';
    $area = $_POST['area'] ?? 0;
    $latitude = !empty($_POST['latitude']) ? $_POST['latitude'] : NULL;
    $longitude = !empty($_POST['longitude']) ? $_POST['longitude'] : NULL;
    $location_link = !empty($_POST['location_link']) ? $_POST['location_link'] : "Not Provided";
    $description = !empty($_POST['description']) ? $_POST['description'] : "No description available";
    $status = 'available';

    $image_name = "";
    if (!empty($_FILES['image']['name'])) {
        $image_name = basename($_FILES['image']['name']);
        $target_path = "../uploads/" . $image_name;
        move_uploaded_file($_FILES['image']['tmp_name'], $target_path);
    }

    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $query = "INSERT INTO land_records (owner_name, location, area, latitude, longitude, description, image, location_link, status) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    $stmt->bind_param("ssddsssss", $owner_name, $location, $area, $latitude, $longitude, $description, $image_name, $location_link, $status);

    if ($stmt->execute()) {
        echo "<script>alert('Land record added successfully!'); window.location.href='dashboard_superadmin.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Land Record</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 500px;
            background: white;
            padding: 20px;
            margin: 50px auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            font-weight: 600;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        input, textarea, button {
            padding: 10px;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
            height: 80px;
        }

        input:focus, textarea:focus {
            border-color: #007BFF;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            transition: 0.3s ease-in-out;
        }

        button {
            background: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }

        button:hover {
            background: #0056b3;
        }

        .back-link {
            display: inline-block;
            margin-top: 10px;
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Upload Land Record</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="text" name="owner_name" placeholder="Owner Name" required>
            <input type="text" name="location" placeholder="Location" required>
            <input type="number" step="0.01" name="area" placeholder="Area (sq.m)" required>
            <input type="text" name="latitude" placeholder="Latitude">
            <input type="text" name="longitude" placeholder="Longitude">
            <textarea name="description" placeholder="Enter property description"></textarea>
            <input type="text" name="location_link" placeholder="Enter Google Maps link or additional property details">
            <input type="file" name="image">
            <button type="submit">Upload</button>
        </form>
        <a href="dashboard_superadmin.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
