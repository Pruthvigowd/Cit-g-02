<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the image name before deleting the record
    $query = "SELECT image FROM land_records WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($image);
        $stmt->fetch();
        $stmt->close();

        // Delete the image file if it exists
        if (!empty($image) && file_exists("../uploads/" . $image)) {
            unlink("../uploads/" . $image);
        }

        // Delete the record from the database
        $deleteQuery = "DELETE FROM land_records WHERE id = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $id);

        if ($deleteStmt->execute()) {
            echo "<script>alert('Land record deleted successfully!'); window.location.href='dashboard_superadmin.php';</script>";
        } else {
            echo "<script>alert('Error deleting record.'); window.location.href='dashboard_superadmin.php';</script>";
        }
        $deleteStmt->close();
    } else {
        echo "<script>alert('Record not found.'); window.location.href='dashboard_superadmin.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='dashboard_superadmin.php';</script>";
}
?>
