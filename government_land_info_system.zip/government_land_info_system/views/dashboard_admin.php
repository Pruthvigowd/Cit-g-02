<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login_admin.php");
    exit();
}

include_once '../config/db.php';
$result = $conn->query("SELECT * FROM land_records ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.8s ease-in-out;
        }

        h2, h3 {
            color: #333;
            font-weight: 600;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #007BFF;
            color: white;
            font-weight: bold;
        }

        tr:hover {
            background: #f1f1f1;
            transition: 0.3s;
        }

        img {
            width: 80px;
            height: auto;
            border-radius: 5px;
            transition: transform 0.3s ease-in-out;
        }

        img:hover {
            transform: scale(1.1);
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            margin-top: 20px;
            text-decoration: none;
            color: white;
            background: #007BFF;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: #0056b3;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard</h2>
        <h3>Land Records</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Owner Name</th>
                <th>Location</th>
                <th>Area (sq.m)</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Location Link</th>
                <th>Image</th>
                <th>Property Details</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['owner_name']; ?></td>
                    <td><?php echo $row['location']; ?></td>
                    <td><?php echo $row['area']; ?></td>
                    <td><?php echo $row['latitude']; ?></td>
                    <td><?php echo $row['longitude']; ?></td>
                    <td>
                        <?php if (!empty($row['latitude']) && !empty($row['longitude'])): ?>
                            <a href="https://www.google.com/maps?q=<?php echo $row['latitude']; ?>,<?php echo $row['longitude']; ?>" target="_blank">View on Map</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><img src="../uploads/<?php echo $row['image']; ?>" alt="Land Image"></td>
                    <td><a href="property_details.php?id=<?php echo $row['id']; ?>">View Details</a></td>
                </tr>
            <?php } ?>
        </table>
        <a href="../controllers/logout.php" class="btn">Logout</a>
    </div>
</body>
</html>
