<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1000px;
            background: white;
            padding: 20px;
            margin: 50px auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        .delete-btn, .add-btn, .upload-btn, .logout-btn {
            background: #007BFF;
            color: white;
            padding: 10px 15px;
            border: none;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        .delete-btn:hover { background: darkred; }
        .add-btn:hover, .upload-btn:hover, .logout-btn:hover { background: #0056b3; }
        .logout-container {
            text-align: right;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logout-container">
            <a href="../controllers/logout.php" class="logout-btn">Logout</a>
        </div>

        <h2>Super Admin Dashboard</h2>
        
        <h3>Land Records</h3>
        <a href="upload_land_record.php" class="upload-btn">Upload Land Record</a>
        <table>
            <tr>
                <th>ID</th>
                <th>Owner Name</th>
                <th>Location</th>
                <th>Area (sq.m)</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Image</th>
                <th>Property Details</th>
                <th>Location Link</th>
                <th>Action</th>
            </tr>
            <?php
            $query = "SELECT * FROM land_records ORDER BY id DESC";
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["owner_name"] . "</td>";
                echo "<td>" . $row["location"] . "</td>";
                echo "<td>" . $row["area"] . "</td>";
                echo "<td>" . $row["latitude"] . "</td>";
                echo "<td>" . $row["longitude"] . "</td>";
                echo "<td><img src='../uploads/" . $row["image"] . "' width='100' height='100'></td>";
                echo "<td><a href='property_details.php?id=" . $row["id"] . "'>View Details</a></td>";
                echo "<td>" . (!empty($row["location_link"]) ? "<a href='" . $row["location_link"] . "' target='_blank'>View Location</a>" : "Not Provided") . "</td>";
                echo "<td><a href='delete_land.php?id=" . $row["id"] . "' onclick='return confirm(\"Are you sure you want to delete this property?\");' class='delete-btn'>Delete</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
        
        <h3>Admin List</h3>
        <a href="add_admin.php" class="add-btn">Add Admin</a>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            <?php
            $query_admins = "SELECT * FROM users WHERE role='admin' ORDER BY id DESC";
            $result_admins = $conn->query($query_admins);
            while ($row_admin = $result_admins->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row_admin["id"] . "</td>";
                echo "<td>" . $row_admin["name"] . "</td>";
                echo "<td>" . $row_admin["email"] . "</td>";
                echo "<td><a href='delete_admin.php?id=" . $row_admin["id"] . "' onclick='return confirm(\"Are you sure you want to delete this admin?\");' class='delete-btn'>Delete</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
