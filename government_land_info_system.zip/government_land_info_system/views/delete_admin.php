<?php
session_start();
if (!isset($_SESSION['superadmin_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login_superadmin.php");
    exit();
}

include_once '../config/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM users WHERE id = ? AND role = 'admin'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Admin deleted!'); window.location.href='dashboard_superadmin.php';</script>";
    } else {
        echo "Error deleting admin: " . $conn->error;
    }
}
?>
