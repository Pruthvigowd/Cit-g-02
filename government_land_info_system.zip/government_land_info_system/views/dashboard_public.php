<?php
session_start();
if (!isset($_SESSION['public_id']) || $_SESSION['role'] !== 'public') {
    header("Location: index.php");
    exit();
}

include_once '../config/db.php';

function checkQuery($result, $conn) {
    if (!$result) {
        die("SQL Error: " . $conn->error);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background: #f4f4f4; }
        .container { margin-top: 50px; width: 80%; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: center; }
        th { background-color: #007BFF; color: white; }
        img { width: 100px; height: auto; border-radius: 5px; }
        .btn { padding: 5px 10px; text-decoration: none; background: #007BFF; color: white; border-radius: 5px; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
<div class="container">
    <h1>Public Dashboard</h1>
    <p>Welcome, Public User!</p>

    <h2>Available Land</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Owner Name</th>
            <th>Location</th>
            <th>Area (sq.m)</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php
        $query = "SELECT id, owner_name, location, area, image FROM land_records WHERE status = 'available'";
        $result = $conn->query($query);
        checkQuery($result, $conn);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['owner_name']}</td>
                        <td>{$row['location']}</td>
                        <td>{$row['area']}</td>
                        <td><img src='../uploads/{$row['image']}' alt='Land Image'></td>
                        <td><a href='property_details.php?id={$row['id']}' class='btn'>View Details</a></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No land records available</td></tr>";
        }
        ?>
    </table>

    <br><br>
    <a href="register.php" class="btn">Register Here</a>
    <br><br>
    <a href="../controllers/logout.php" class="btn">Logout</a>
</div>
</body>
</html>
