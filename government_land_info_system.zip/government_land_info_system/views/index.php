<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOVERNMENT LAND INFORMATION SYSTEM</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            /* background: linear-gradient(to right, #000000, #555555); */
            background-image: url(https://wallpapers.com/images/file/real-estate-portrait-image-x3hw644igbpeusd2.jpg);
            background-repeat: no-repeat;
            color: black;
            font-weight: Larger;
            margin: 0;
            padding: 0;
        }

        img{
            width: 100px;
            height: 100px;
            padding-top: 50px;
        }

        h1 {
            margin-top: 50px;
            font-size: 2.5em;
            animation: fadeIn 1.5s ease-in-out;
        }
        .container {
            width: 80%;
            margin: auto;
            text-align: left;
            padding: 20px;
        }
        .section {
            margin-bottom: 20px;
        }
        h2 {
            color: #ffcc00;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin: 5px 0;
        }
        .highlight {
            color: #ffcc00;
            font-weight: bold;
        }
        .buttons {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .column {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 50%;
        }
        a {
            display: block;
            width: 250px;
            margin: 10px;
            padding: 15px;
            background: #ffffff;
            color: #333333;
            text-decoration: none;
            font-size: 1.2em;
            font-weight: bold;
            border-radius: 25px;
            transition: all 0.3s ease-in-out;
        }
        a:hover {
            background: #000000;
            color: white;
            transform: scale(1.1);
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <img src="https://png.pngtree.com/png-clipart/20221216/original/pngtree-house-property-logo-real-estate-design-buildings-clipart-png-image_8750111.png" alt="">
    <h1>Welcome to Government land Information System </h1>
    <div class="buttons">
        <div class="column">
            <a href="signup_superadmin.php">Super Admin Signup</a>
            <a href="signup_admin.php">Admin Signup</a>
            <a href="signup_public.php">Public Signup</a>
        </div>
        <div class="column">
            <a href="login_superadmin.php">Super Admin Login</a>
            <a href="login_admin.php">Admin Login</a>
            <a href="login_public.php">Public Login</a>
        </div>
    </div>
    <div class="container">
        <div class="section">
        <h2>Government Land Information System (GLIS)</h2>
        <p>The Government Land Information System (GLIS) is an advanced digital platform designed to streamline the management, storage, and accessibility of government land records. It aims to enhance transparency, accountability, and efficiency in land administration while providing an easy-to-use interface for government officials and the public.</p>
        </div>
        <div class="section">
            <h2>Key Objectives of GLIS</h2>
            <ul>
                <li><span class="highlight">✅ Digitized Land Records:</span> Eliminates manual paperwork by storing all land data securely in a centralized database.</li>
                <li><span class="highlight">✅ Role-Based Access:</span> Ensures that only authorized users can manage or view specific land records.</li>
                <li><span class="highlight">✅ Transparency & Public Access:</span> Allows citizens to check land availability and ownership details online.</li>
                <li><span class="highlight">✅ Efficient Land Management:</span> Helps government officials track, approve, and update land status in real-time.</li>
                <li><span class="highlight">✅ Geospatial Mapping:</span> Integrates maps for visual representation of land locations.</li>
            </ul>
        </div>
        <div class="section">
            <h2>User Roles & Their Functionalities</h2>
            <p><strong>1. Super Admin (Government Authority)</strong><br>Has full control over the system.<br>Adds and manages Admin users.<br>Uploads and updates land records with images and location details.<br>Sets the default status of land records (Available, Pending, Approved).</p>
            <p><strong>2. Admin (Land Department Officials)</strong><br>Reviews, verifies, and approves land records before making them public.<br>Ensures accurate and legal documentation of land details.<br>Manages updates on land status (e.g., sold, under review, available).</p>
            <p><strong>3. Public Users (General Citizens & Buyers)</strong><br>Searches and views land records available for public access.<br>Checks land details, including size, location, and status.<br>Views the land’s exact position on an interactive map.</p>
        </div>
        <div class="section">
            <h2>Core Features of GLIS</h2>
            <ul>
                <li><span class="highlight">🔹 Secure User Authentication:</span> Ensures authorized access.</li>
                <li><span class="highlight">🔹 Land Record Management:</span> Super Admin can manage land records.</li>
                <li><span class="highlight">🔹 Approval System:</span> Admins verify records before publishing.</li>
                <li><span class="highlight">🔹 Interactive Map Integration:</span> Displays land locations visually.</li>
                <li><span class="highlight">🔹 Real-Time Availability Updates:</span> Reflects instant land status changes.</li>
                <li><span class="highlight">🔹 User-Friendly Dashboard:</span> Simplifies access for different user roles.</li>
            </ul>
        </div>
        <div class="section">
            <h2>Benefits of GLIS</h2>
            <ul>
                <li>✅ Transparency: Reduces corruption.</li>
                <li>✅ Time-Saving: Eliminates manual paperwork.</li>
                <li>✅ Secure & Reliable: Ensures data integrity.</li>
                <li>✅ Easy Navigation: User-friendly interface.</li>
                <li>✅ Improved Land Governance: Enhances monitoring & management.</li>
            </ul>
        </div>
        <div class="section">
            <h2>Conclusion</h2>
            <p>The Government Land Information System (GLIS) is a modern solution for managing government land records effectively. By digitizing the process, it improves accessibility, speeds up approvals, and enhances public trust in land administration.</p>
        </div>
    </div>
</body>
</html>