<?php
require_once 'functions.php';  // Ensure functions.php is included
$servername = "localhost";
$username = "land_user";
$password = "Mysql";
$database = "land_info_system";

// Create a secure database connection
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4"); // Set charset to avoid encoding issues
?>
