<?php
function sanitize($data) {
    global $conn;
    return htmlspecialchars(strip_tags(mysqli_real_escape_string($conn, trim($data))));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}
?>
