<?php
include_once '../config/functions.php';
include_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize($_POST["name"]);
    $email = sanitize($_POST["email"]);
    $phone = sanitize($_POST["phone"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $role = "public"; // Fixed role for this signup

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        header("Location: ../views/signup_public.php?error=Email already exists!");
        exit();
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $password, $role);

    if ($stmt->execute()) {
        header("Location: ../views/login_public.php?success=Signup successful! Please login.");
        exit();
    } else {
        header("Location: ../views/signup_public.php?error=Signup failed! Try again.");
        exit();
    }
}
?>
