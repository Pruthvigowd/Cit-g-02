<?php
session_start(); // Start session

require_once '../config/db.php';  // Database connection
require_once '../config/functions.php';  // Function definitions

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $role = 'superadmin';

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        header("Location: ../views/signup_superadmin.php?error=Email already registered");
        exit();
    }
    $stmt->close();

    // Insert new Super Admin into the database
    $stmt = $conn->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $password, $role);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: ../views/login_superadmin.php?success=Signup successful. Please login.");
        exit();
    } else {
        $stmt->close();
        header("Location: ../views/signup_superadmin.php?error=Signup failed. Try again.");
        exit();
    }
} else {
    header("Location: ../views/signup_superadmin.php");
    exit();
}
?>
