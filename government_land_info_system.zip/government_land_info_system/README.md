http://localhost/government_land_info_system/views/index.php

http://localhost/phpmyadmin/
